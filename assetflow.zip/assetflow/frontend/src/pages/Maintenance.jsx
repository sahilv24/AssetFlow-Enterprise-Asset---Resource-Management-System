import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';

export default function Maintenance() {
  const { user } = useAuth();
  const canManage = ['Admin', 'AssetManager'].includes(user.role);
  const [requests, setRequests] = useState([]);
  const [assets, setAssets] = useState([]);
  const [form, setForm] = useState({ assetId: '', issueDescription: '', priority: 'Medium' });

  const load = async () => {
    const [r, a] = await Promise.all([api.get('/maintenance'), api.get('/assets')]);
    setRequests(r.data); setAssets(a.data);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post('/maintenance', form);
    setForm({ assetId: '', issueDescription: '', priority: 'Medium' });
    load();
  };

  const decide = async (id, decision) => {
    const rejectionReason = decision === 'Rejected' ? prompt('Rejection reason:') || '' : '';
    await api.patch(`/maintenance/${id}/decision`, { decision, rejectionReason });
    load();
  };
  const assignTech = async (id) => {
    const technician = prompt('Technician name:');
    if (!technician) return;
    await api.patch(`/maintenance/${id}/assign-technician`, { technician });
    load();
  };
  const startProgress = async (id) => { await api.patch(`/maintenance/${id}/start-progress`); load(); };
  const resolve = async (id) => {
    const resolutionNotes = prompt('Resolution notes:') || '';
    await api.patch(`/maintenance/${id}/resolve`, { resolutionNotes });
    load();
  };

  return (
    <div>
      <div className="section-title">Maintenance Management</div>

      <div className="card">
        <strong>Raise Maintenance Request</strong>
        <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
          <div className="form-row">
            <label>Asset</label>
            <select value={form.assetId} onChange={(e) => setForm({ ...form, assetId: e.target.value })} required>
              <option value="">-- select --</option>
              {assets.map((a) => <option key={a._id} value={a._id}>{a.assetTag} - {a.name}</option>)}
            </select>
          </div>
          <div className="form-row">
            <label>Priority</label>
            <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              {['Low', 'Medium', 'High', 'Critical'].map((p) => <option key={p}>{p}</option>)}
            </select>
          </div>
          <div className="form-row" style={{ gridColumn: '1 / -1' }}>
            <label>Describe the issue</label>
            <textarea rows={2} value={form.issueDescription} onChange={(e) => setForm({ ...form, issueDescription: e.target.value })} required />
          </div>
          <div><button className="btn">Raise Request</button></div>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Asset</th><th>Issue</th><th>Priority</th><th>Status</th><th>Raised By</th><th>Actions</th></tr></thead>
          <tbody>
            {requests.map((r) => (
              <tr key={r._id}>
                <td>{r.asset?.assetTag} - {r.asset?.name}</td>
                <td>{r.issueDescription}</td>
                <td>{r.priority}</td>
                <td><StatusBadge status={r.status} /></td>
                <td>{r.raisedBy?.name}</td>
                <td>
                  {canManage && r.status === 'Pending' && (
                    <>
                      <button className="btn small" onClick={() => decide(r._id, 'Approved')}>Approve</button>{' '}
                      <button className="btn small danger" onClick={() => decide(r._id, 'Rejected')}>Reject</button>
                    </>
                  )}
                  {canManage && r.status === 'Approved' && <button className="btn small secondary" onClick={() => assignTech(r._id)}>Assign Technician</button>}
                  {canManage && r.status === 'Technician Assigned' && <button className="btn small secondary" onClick={() => startProgress(r._id)}>Start Progress</button>}
                  {canManage && r.status === 'In Progress' && <button className="btn small" onClick={() => resolve(r._id)}>Resolve</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
