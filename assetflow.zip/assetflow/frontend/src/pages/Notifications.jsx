import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function Notifications() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [logs, setLogs] = useState([]);
  const [tab, setTab] = useState('notifications');

  const load = async () => {
    const n = await api.get('/notifications');
    setNotifications(n.data);
    if (user.role === 'Admin') {
      const l = await api.get('/logs');
      setLogs(l.data);
    }
  };
  useEffect(() => { load(); }, []);

  const markRead = async (id) => { await api.patch(`/notifications/${id}/read`); load(); };
  const markAllRead = async () => { await api.patch('/notifications/read-all'); load(); };

  return (
    <div>
      <div className="section-title">Activity Logs & Notifications</div>
      <div className="tabs">
        <button className={tab === 'notifications' ? 'active' : ''} onClick={() => setTab('notifications')}>My Notifications</button>
        {user.role === 'Admin' && <button className={tab === 'logs' ? 'active' : ''} onClick={() => setTab('logs')}>Full Activity Log</button>}
      </div>

      {tab === 'notifications' && (
        <div className="card">
          <div className="flex-between"><strong>Notifications</strong><button className="btn small secondary" onClick={markAllRead}>Mark all read</button></div>
          {notifications.length === 0 && <p className="muted">No notifications.</p>}
          {notifications.map((n) => (
            <div key={n._id} className={`notif-item ${n.isRead ? '' : 'unread'}`}>
              <div className="flex-between">
                <span>[{n.type}] {n.message}</span>
                {!n.isRead && <button className="btn small secondary" onClick={() => markRead(n._id)}>Mark read</button>}
              </div>
              <div className="muted">{new Date(n.createdAt).toLocaleString()}</div>
            </div>
          ))}
        </div>
      )}

      {tab === 'logs' && (
        <div className="card">
          <table>
            <thead><tr><th>When</th><th>User</th><th>Module</th><th>Action</th></tr></thead>
            <tbody>
              {logs.map((l) => (
                <tr key={l._id}>
                  <td>{new Date(l.createdAt).toLocaleString()}</td>
                  <td>{l.user?.name} ({l.user?.role})</td>
                  <td>{l.module}</td>
                  <td>{l.action}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
