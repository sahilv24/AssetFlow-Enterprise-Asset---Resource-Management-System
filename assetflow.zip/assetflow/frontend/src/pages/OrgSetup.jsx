import { useEffect, useState } from 'react';
import api from '../api/axios';
import StatusBadge from '../components/StatusBadge';

export default function OrgSetup() {
  const [tab, setTab] = useState('departments');
  return (
    <div>
      <div className="section-title">Organization Setup</div>
      <div className="tabs">
        <button className={tab === 'departments' ? 'active' : ''} onClick={() => setTab('departments')}>Department Management</button>
        <button className={tab === 'categories' ? 'active' : ''} onClick={() => setTab('categories')}>Asset Category Management</button>
        <button className={tab === 'employees' ? 'active' : ''} onClick={() => setTab('employees')}>Employee Directory</button>
      </div>
      {tab === 'departments' && <Departments />}
      {tab === 'categories' && <Categories />}
      {tab === 'employees' && <Employees />}
    </div>
  );
}

function Departments() {
  const [departments, setDepartments] = useState([]);
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', departmentHead: '', parentDepartment: '' });

  const load = async () => {
    const [d, u] = await Promise.all([api.get('/departments'), api.get('/employees')]);
    setDepartments(d.data);
    setUsers(u.data);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post('/departments', {
      name: form.name,
      departmentHead: form.departmentHead || null,
      parentDepartment: form.parentDepartment || null,
    });
    setForm({ name: '', departmentHead: '', parentDepartment: '' });
    load();
  };

  const deactivate = async (id) => { await api.patch(`/departments/${id}/deactivate`); load(); };

  return (
    <div>
      <div className="card">
        <strong>Create Department</strong>
        <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
          <div className="form-row">
            <label>Name</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div className="form-row">
            <label>Department Head</label>
            <select value={form.departmentHead} onChange={(e) => setForm({ ...form, departmentHead: e.target.value })}>
              <option value="">-- none --</option>
              {users.map((u) => <option key={u._id} value={u._id}>{u.name} ({u.role})</option>)}
            </select>
          </div>
          <div className="form-row">
            <label>Parent Department (optional)</label>
            <select value={form.parentDepartment} onChange={(e) => setForm({ ...form, parentDepartment: e.target.value })}>
              <option value="">-- none --</option>
              {departments.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}><button className="btn">Create</button></div>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Name</th><th>Head</th><th>Parent</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {departments.map((d) => (
              <tr key={d._id}>
                <td>{d.name}</td>
                <td>{d.departmentHead?.name || '-'}</td>
                <td>{d.parentDepartment?.name || '-'}</td>
                <td><StatusBadge status={d.status} /></td>
                <td>{d.status === 'Active' && <button className="btn small danger" onClick={() => deactivate(d._id)}>Deactivate</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Categories() {
  const [categories, setCategories] = useState([]);
  const [form, setForm] = useState({ name: '', description: '', customFieldLabel: '' });

  const load = async () => { const res = await api.get('/categories'); setCategories(res.data); };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    const customFields = form.customFieldLabel
      ? [{ key: form.customFieldLabel.toLowerCase().replace(/\s+/g, '_'), label: form.customFieldLabel, type: 'text' }]
      : [];
    await api.post('/categories', { name: form.name, description: form.description, customFields });
    setForm({ name: '', description: '', customFieldLabel: '' });
    load();
  };

  const deactivate = async (id) => { await api.patch(`/categories/${id}/deactivate`); load(); };

  return (
    <div>
      <div className="card">
        <strong>Create Asset Category</strong>
        <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
          <div className="form-row">
            <label>Name (e.g. Electronics, Furniture, Vehicles)</label>
            <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div className="form-row">
            <label>Description</label>
            <input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="form-row">
            <label>Optional custom field (e.g. Warranty Period)</label>
            <input value={form.customFieldLabel} onChange={(e) => setForm({ ...form, customFieldLabel: e.target.value })} />
          </div>
          <div style={{ alignSelf: 'end' }}><button className="btn">Create</button></div>
        </form>
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Name</th><th>Description</th><th>Custom Fields</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c._id}>
                <td>{c.name}</td>
                <td>{c.description}</td>
                <td>{c.customFields?.map((f) => f.label).join(', ') || '-'}</td>
                <td><StatusBadge status={c.status} /></td>
                <td>{c.status === 'Active' && <button className="btn small danger" onClick={() => deactivate(c._id)}>Deactivate</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function Employees() {
  const [employees, setEmployees] = useState([]);

  const load = async () => { const res = await api.get('/employees'); setEmployees(res.data); };
  useEffect(() => { load(); }, []);

  const changeRole = async (id, role) => { await api.patch(`/employees/${id}/role`, { role }); load(); };
  const toggleStatus = async (emp) => {
    await api.put(`/employees/${emp._id}`, { ...emp, status: emp.status === 'Active' ? 'Inactive' : 'Active', department: emp.department?._id });
    load();
  };

  return (
    <div className="card">
      <strong>Employee Directory</strong>
      <p className="muted">This is the only place roles are assigned. Promote employees to Department Head or Asset Manager here.</p>
      <table>
        <thead><tr><th>Name</th><th>Email</th><th>Department</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
        <tbody>
          {employees.map((e) => (
            <tr key={e._id}>
              <td>{e.name}</td>
              <td>{e.email}</td>
              <td>{e.department?.name || '-'}</td>
              <td><StatusBadge status={e.role} /></td>
              <td><StatusBadge status={e.status} /></td>
              <td>
                {e.role !== 'Admin' && (
                  <select defaultValue="" onChange={(ev) => ev.target.value && changeRole(e._id, ev.target.value)}>
                    <option value="">Change role...</option>
                    <option value="Employee">Employee</option>
                    <option value="DepartmentHead">Department Head</option>
                    <option value="AssetManager">Asset Manager</option>
                  </select>
                )}
                {' '}
                {e.role !== 'Admin' && <button className="btn small secondary" onClick={() => toggleStatus(e)}>Toggle Status</button>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
