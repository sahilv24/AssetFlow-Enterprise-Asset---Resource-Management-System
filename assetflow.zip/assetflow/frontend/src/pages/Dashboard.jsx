import { useEffect, useState } from 'react';
import api from '../api/axios';
import StatusBadge from '../components/StatusBadge';

export default function Dashboard() {
  const [kpis, setKpis] = useState(null);
  const [overdueAllocations, setOverdueAllocations] = useState([]);
  const [upcomingReturns, setUpcomingReturns] = useState([]);

  const load = async () => {
    const [k, allocs] = await Promise.all([
      api.get('/dashboard/kpis'),
      api.get('/allocations'),
    ]);
    setKpis(k.data);
    const now = new Date();
    const active = allocs.data.filter((a) => a.status === 'Active' && a.expectedReturnDate);
    setOverdueAllocations(active.filter((a) => new Date(a.expectedReturnDate) < now));
    setUpcomingReturns(active.filter((a) => new Date(a.expectedReturnDate) >= now));
  };

  useEffect(() => { load(); }, []);

  if (!kpis) return <div>Loading dashboard...</div>;

  const cards = [
    { label: 'Assets Available', value: kpis.assetsAvailable },
    { label: 'Assets Allocated', value: kpis.assetsAllocated },
    { label: 'Maintenance Today', value: kpis.maintenanceToday },
    { label: 'Active Bookings', value: kpis.activeBookings },
    { label: 'Pending Transfers', value: kpis.pendingTransfers },
    { label: 'Upcoming Returns', value: kpis.upcomingReturns },
  ];

  return (
    <div>
      <div className="section-title">Dashboard</div>
      <div className="kpi-grid">
        {cards.map((c) => (
          <div className="kpi-card" key={c.label}>
            <div className="value">{c.value}</div>
            <div className="label">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="flex-between"><strong>Overdue Returns</strong></div>
        {overdueAllocations.length === 0 ? (
          <p className="muted">No overdue returns.</p>
        ) : (
          <table>
            <thead><tr><th>Asset</th><th>Held by</th><th>Expected Return</th></tr></thead>
            <tbody>
              {overdueAllocations.map((a) => (
                <tr key={a._id}>
                  <td>{a.asset?.assetTag} - {a.asset?.name}</td>
                  <td>{a.allocatedTo?.name || a.department?.name || '-'}</td>
                  <td><StatusBadge status="Overdue" /> {new Date(a.expectedReturnDate).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <div className="flex-between"><strong>Upcoming Returns</strong></div>
        {upcomingReturns.length === 0 ? (
          <p className="muted">No upcoming returns.</p>
        ) : (
          <table>
            <thead><tr><th>Asset</th><th>Held by</th><th>Expected Return</th></tr></thead>
            <tbody>
              {upcomingReturns.map((a) => (
                <tr key={a._id}>
                  <td>{a.asset?.assetTag} - {a.asset?.name}</td>
                  <td>{a.allocatedTo?.name || a.department?.name || '-'}</td>
                  <td>{new Date(a.expectedReturnDate).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
