import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';

export default function Assets() {
  const { user } = useAuth();
  const canRegister = ['Admin', 'AssetManager'].includes(user.role);
  const [assets, setAssets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [q, setQ] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState(null);

  const [form, setForm] = useState({
    name: '', category: '', serialNumber: '', acquisitionDate: '', acquisitionCost: '',
    condition: 'New', location: '', department: '', isBookable: false, qrCode: '',
  });

  const load = async (query = '') => {
    const [a, c, d] = await Promise.all([
      api.get(`/assets${query ? `?q=${encodeURIComponent(query)}` : ''}`),
      api.get('/categories'),
      api.get('/departments'),
    ]);
    setAssets(a.data); setCategories(c.data); setDepartments(d.data);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post('/assets', { ...form, department: form.department || null });
    setForm({ name: '', category: '', serialNumber: '', acquisitionDate: '', acquisitionCost: '', condition: 'New', location: '', department: '', isBookable: false, qrCode: '' });
    setShowForm(false);
    load();
  };

  const openHistory = async (asset) => {
    setSelected(asset);
    const res = await api.get(`/assets/${asset._id}/history`);
    setHistory(res.data);
  };

  return (
    <div>
      <div className="flex-between">
        <div className="section-title">Assets</div>
        {canRegister && <button className="btn" onClick={() => setShowForm(!showForm)}>{showForm ? 'Cancel' : '+ Register Asset'}</button>}
      </div>

      {showForm && (
        <div className="card">
          <form onSubmit={submit} className="form-grid">
            <div className="form-row"><label>Name</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="form-row">
              <label>Category</label>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} required>
                <option value="">-- select --</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
            </div>
            <div className="form-row"><label>Serial Number</label><input value={form.serialNumber} onChange={(e) => setForm({ ...form, serialNumber: e.target.value })} /></div>
            <div className="form-row"><label>QR Code</label><input value={form.qrCode} onChange={(e) => setForm({ ...form, qrCode: e.target.value })} /></div>
            <div className="form-row"><label>Acquisition Date</label><input type="date" value={form.acquisitionDate} onChange={(e) => setForm({ ...form, acquisitionDate: e.target.value })} /></div>
            <div className="form-row"><label>Acquisition Cost</label><input type="number" value={form.acquisitionCost} onChange={(e) => setForm({ ...form, acquisitionCost: e.target.value })} /></div>
            <div className="form-row">
              <label>Condition</label>
              <select value={form.condition} onChange={(e) => setForm({ ...form, condition: e.target.value })}>
                {['New', 'Good', 'Fair', 'Poor', 'Damaged'].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-row"><label>Location</label><input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
            <div className="form-row">
              <label>Department</label>
              <select value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })}>
                <option value="">-- none --</option>
                {departments.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
              </select>
            </div>
            <div className="form-row">
              <label><input type="checkbox" style={{ width: 'auto', marginRight: 6 }} checked={form.isBookable} onChange={(e) => setForm({ ...form, isBookable: e.target.checked })} />Shared / bookable resource</label>
            </div>
            <div style={{ alignSelf: 'end' }}><button className="btn">Register</button></div>
          </form>
        </div>
      )}

      <div className="card">
        <div className="form-row" style={{ maxWidth: 400 }}>
          <input placeholder="Search by tag, serial, QR, name..." value={q} onChange={(e) => { setQ(e.target.value); load(e.target.value); }} />
        </div>
        <table>
          <thead><tr><th>Tag</th><th>Name</th><th>Category</th><th>Status</th><th>Condition</th><th>Location</th><th>Bookable</th><th></th></tr></thead>
          <tbody>
            {assets.map((a) => (
              <tr key={a._id}>
                <td>{a.assetTag}</td>
                <td>{a.name}</td>
                <td>{a.category?.name}</td>
                <td><StatusBadge status={a.status} /></td>
                <td>{a.condition}</td>
                <td>{a.location}</td>
                <td>{a.isBookable ? 'Yes' : 'No'}</td>
                <td><button className="btn small secondary" onClick={() => openHistory(a)}>History</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selected && history && (
        <div className="card">
          <div className="flex-between">
            <strong>History: {selected.assetTag} - {selected.name}</strong>
            <button className="btn small secondary" onClick={() => { setSelected(null); setHistory(null); }}>Close</button>
          </div>
          <p><strong>Allocation History</strong></p>
          <table>
            <thead><tr><th>Allocated To</th><th>Department</th><th>Date</th><th>Returned</th><th>Status</th></tr></thead>
            <tbody>
              {history.allocationHistory.map((h) => (
                <tr key={h._id}>
                  <td>{h.allocatedTo?.name || '-'}</td>
                  <td>{h.department?.name || '-'}</td>
                  <td>{new Date(h.allocationDate).toLocaleDateString()}</td>
                  <td>{h.actualReturnDate ? new Date(h.actualReturnDate).toLocaleDateString() : '-'}</td>
                  <td><StatusBadge status={h.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
          <p style={{ marginTop: 16 }}><strong>Maintenance History</strong></p>
          <table>
            <thead><tr><th>Issue</th><th>Priority</th><th>Status</th><th>Raised By</th></tr></thead>
            <tbody>
              {history.maintenanceHistory.map((h) => (
                <tr key={h._id}>
                  <td>{h.issueDescription}</td>
                  <td>{h.priority}</td>
                  <td><StatusBadge status={h.status} /></td>
                  <td>{h.raisedBy?.name}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
