import { useEffect, useState } from 'react';
import api from '../api/axios';

export default function Reports() {
  const [assets, setAssets] = useState([]);
  const [maintenance, setMaintenance] = useState([]);
  const [allocations, setAllocations] = useState([]);
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    (async () => {
      const [a, m, al, b] = await Promise.all([
        api.get('/assets'), api.get('/maintenance'), api.get('/allocations'), api.get('/bookings'),
      ]);
      setAssets(a.data); setMaintenance(m.data); setAllocations(al.data); setBookings(b.data);
    })();
  }, []);

  const byCategory = {};
  assets.forEach((a) => { const cat = a.category?.name || 'Uncategorized'; byCategory[cat] = (byCategory[cat] || 0) + 1; });

  const maintenanceByAsset = {};
  maintenance.forEach((m) => {
    const key = m.asset ? `${m.asset.assetTag} - ${m.asset.name}` : 'Unknown';
    maintenanceByAsset[key] = (maintenanceByAsset[key] || 0) + 1;
  });

  const deptAllocations = {};
  allocations.filter((a) => a.status === 'Active').forEach((a) => {
    const key = a.department?.name || 'Unassigned';
    deptAllocations[key] = (deptAllocations[key] || 0) + 1;
  });

  const idleAssets = assets.filter((a) => a.status === 'Available');

  const exportCSV = () => {
    const rows = [['Asset Tag', 'Name', 'Category', 'Status', 'Condition', 'Location']];
    assets.forEach((a) => rows.push([a.assetTag, a.name, a.category?.name || '', a.status, a.condition, a.location]));
    const csv = rows.map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'assetflow_assets_report.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <div className="flex-between">
        <div className="section-title">Reports & Analytics</div>
        <button className="btn" onClick={exportCSV}>Export Assets CSV</button>
      </div>

      <div className="card">
        <strong>Asset Utilization: Category Breakdown</strong>
        <table style={{ marginTop: 10 }}>
          <thead><tr><th>Category</th><th>Count</th></tr></thead>
          <tbody>{Object.entries(byCategory).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody>
        </table>
      </div>

      <div className="card">
        <strong>Idle Assets (currently Available)</strong>
        <p className="muted">{idleAssets.length} asset(s) not in use.</p>
      </div>

      <div className="card">
        <strong>Maintenance Frequency by Asset</strong>
        <table style={{ marginTop: 10 }}>
          <thead><tr><th>Asset</th><th>Requests</th></tr></thead>
          <tbody>{Object.entries(maintenanceByAsset).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody>
        </table>
      </div>

      <div className="card">
        <strong>Department-wise Allocation Summary</strong>
        <table style={{ marginTop: 10 }}>
          <thead><tr><th>Department</th><th>Active Allocations</th></tr></thead>
          <tbody>{Object.entries(deptAllocations).map(([k, v]) => <tr key={k}><td>{k}</td><td>{v}</td></tr>)}</tbody>
        </table>
      </div>

      <div className="card">
        <strong>Resource Booking Volume</strong>
        <p className="muted">{bookings.length} total bookings recorded ({bookings.filter((b) => b.status === 'Upcoming' || b.status === 'Ongoing').length} active).</p>
      </div>
    </div>
  );
}
