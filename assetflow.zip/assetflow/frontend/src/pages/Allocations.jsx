import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';

export default function Allocations() {
  const { user } = useAuth();
  const canAllocate = ['Admin', 'AssetManager', 'DepartmentHead'].includes(user.role);
  const canApprove = canAllocate;

  const [allocations, setAllocations] = useState([]);
  const [assets, setAssets] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [conflict, setConflict] = useState(null);
  const [form, setForm] = useState({ assetId: '', allocatedTo: '', expectedReturnDate: '' });

  const load = async () => {
    const [al, as, em] = await Promise.all([
      api.get('/allocations'), api.get('/assets?status=Available'), api.get('/employees'),
    ]);
    setAllocations(al.data); setAssets(as.data); setEmployees(em.data);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    setConflict(null);
    try {
      await api.post('/allocations', form);
      setForm({ assetId: '', allocatedTo: '', expectedReturnDate: '' });
      load();
    } catch (err) {
      if (err.response?.status === 409) setConflict(err.response.data);
      else alert(err.response?.data?.message || 'Failed to allocate');
    }
  };

  const requestTransfer = async (allocationId) => {
    const requestedTo = prompt('Employee ID to transfer to (see Employee Directory):');
    if (!requestedTo) return;
    await api.post('/allocations/transfer-request', { allocationId, requestedTo });
    load();
  };

  const resolveTransfer = async (id, decision) => { await api.patch(`/allocations/${id}/transfer-decision`, { decision }); load(); };
  const returnAsset = async (id) => {
    const conditionNotes = prompt('Condition check-in notes (optional):') || '';
    await api.patch(`/allocations/${id}/return`, { conditionNotes });
    load();
  };

  return (
    <div>
      <div className="section-title">Asset Allocation & Transfer</div>

      {canAllocate && (
        <div className="card">
          <strong>Allocate Asset</strong>
          <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
            <div className="form-row">
              <label>Available Asset</label>
              <select value={form.assetId} onChange={(e) => setForm({ ...form, assetId: e.target.value })} required>
                <option value="">-- select --</option>
                {assets.map((a) => <option key={a._id} value={a._id}>{a.assetTag} - {a.name}</option>)}
              </select>
            </div>
            <div className="form-row">
              <label>Allocate To (Employee)</label>
              <select value={form.allocatedTo} onChange={(e) => setForm({ ...form, allocatedTo: e.target.value })}>
                <option value="">-- select --</option>
                {employees.map((e) => <option key={e._id} value={e._id}>{e.name}</option>)}
              </select>
            </div>
            <div className="form-row">
              <label>Expected Return Date (optional)</label>
              <input type="date" value={form.expectedReturnDate} onChange={(e) => setForm({ ...form, expectedReturnDate: e.target.value })} />
            </div>
            <div style={{ alignSelf: 'end' }}><button className="btn">Allocate</button></div>
          </form>
          {conflict && (
            <div className="error-text" style={{ marginTop: 8 }}>
              {conflict.message}
              {conflict.transferAvailable && (
                <button className="btn small" style={{ marginLeft: 10 }} onClick={() => requestTransfer(conflict.currentAllocation._id)}>
                  Request Transfer
                </button>
              )}
            </div>
          )}
        </div>
      )}

      <div className="card">
        <table>
          <thead>
            <tr><th>Asset</th><th>Held By</th><th>Expected Return</th><th>Status</th><th>Transfer</th><th>Actions</th></tr>
          </thead>
          <tbody>
            {allocations.map((a) => (
              <tr key={a._id}>
                <td>{a.asset?.assetTag} - {a.asset?.name}</td>
                <td>{a.allocatedTo?.name || a.department?.name || '-'}</td>
                <td>{a.expectedReturnDate ? new Date(a.expectedReturnDate).toLocaleDateString() : '-'}</td>
                <td><StatusBadge status={a.status} /></td>
                <td>{a.transferRequest?.status !== 'None' ? <StatusBadge status={a.transferRequest.status} /> : '-'}</td>
                <td>
                  {a.status === 'Active' && (
                    <>
                      {a.transferRequest?.status !== 'Requested' && (
                        <button className="btn small secondary" onClick={() => requestTransfer(a._id)}>Request Transfer</button>
                      )}
                      {a.transferRequest?.status === 'Requested' && canApprove && (
                        <>
                          <button className="btn small" onClick={() => resolveTransfer(a._id, 'Approved')}>Approve Transfer</button>{' '}
                          <button className="btn small danger" onClick={() => resolveTransfer(a._id, 'Rejected')}>Reject</button>
                        </>
                      )}
                      {' '}
                      {canApprove && <button className="btn small secondary" onClick={() => returnAsset(a._id)}>Mark Returned</button>}
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
