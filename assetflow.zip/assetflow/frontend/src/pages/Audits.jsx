import { useEffect, useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';
import StatusBadge from '../components/StatusBadge';

export default function Audits() {
  const { user } = useAuth();
  const canManage = ['Admin', 'AssetManager'].includes(user.role);
  const [cycles, setCycles] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState({ name: '', scopeDepartment: '', scopeLocation: '', startDate: '', endDate: '', auditors: [] });
  const [active, setActive] = useState(null);

  const load = async () => {
    const [c, d, e] = await Promise.all([api.get('/audits'), api.get('/departments'), api.get('/employees')]);
    setCycles(c.data); setDepartments(d.data); setEmployees(e.data);
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post('/audits', { ...form, scopeDepartment: form.scopeDepartment || null });
    setForm({ name: '', scopeDepartment: '', scopeLocation: '', startDate: '', endDate: '', auditors: [] });
    load();
  };

  const openCycle = async (id) => {
    const res = await api.get(`/audits/${id}`);
    setActive(res.data);
  };

  const markItem = async (assetId, result) => {
    const notes = result !== 'Verified' ? (prompt('Notes (optional):') || '') : '';
    const res = await api.patch(`/audits/${active._id}/mark-item`, { assetId, result, notes });
    setActive(res.data);
    load();
  };

  const closeCycle = async () => {
    if (!confirm('Close this audit cycle? This will lock it and update flagged asset statuses.')) return;
    await api.patch(`/audits/${active._id}/close`);
    openCycle(active._id);
    load();
  };

  return (
    <div>
      <div className="section-title">Asset Audit</div>

      {canManage && (
        <div className="card">
          <strong>Create Audit Cycle</strong>
          <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
            <div className="form-row"><label>Name</label><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></div>
            <div className="form-row">
              <label>Scope: Department (optional)</label>
              <select value={form.scopeDepartment} onChange={(e) => setForm({ ...form, scopeDepartment: e.target.value })}>
                <option value="">-- any --</option>
                {departments.map((d) => <option key={d._id} value={d._id}>{d.name}</option>)}
              </select>
            </div>
            <div className="form-row"><label>Scope: Location (optional)</label><input value={form.scopeLocation} onChange={(e) => setForm({ ...form, scopeLocation: e.target.value })} /></div>
            <div className="form-row"><label>Start Date</label><input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} required /></div>
            <div className="form-row"><label>End Date</label><input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} required /></div>
            <div className="form-row">
              <label>Auditors</label>
              <select multiple value={form.auditors} onChange={(e) => setForm({ ...form, auditors: Array.from(e.target.selectedOptions, (o) => o.value) })}>
                {employees.map((emp) => <option key={emp._id} value={emp._id}>{emp.name}</option>)}
              </select>
            </div>
            <div style={{ alignSelf: 'end' }}><button className="btn">Create Cycle</button></div>
          </form>
        </div>
      )}

      <div className="card">
        <table>
          <thead><tr><th>Name</th><th>Scope</th><th>Dates</th><th>Auditors</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {cycles.map((c) => (
              <tr key={c._id}>
                <td>{c.name}</td>
                <td>{c.scopeDepartment?.name || c.scopeLocation || 'All'}</td>
                <td>{new Date(c.startDate).toLocaleDateString()} - {new Date(c.endDate).toLocaleDateString()}</td>
                <td>{c.auditors?.map((a) => a.name).join(', ')}</td>
                <td><StatusBadge status={c.status} /></td>
                <td><button className="btn small secondary" onClick={() => openCycle(c._id)}>Open</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {active && (
        <div className="card">
          <div className="flex-between">
            <strong>{active.name}</strong>
            <div>
              {canManage && active.status !== 'Closed' && <button className="btn danger small" onClick={closeCycle}>Close Cycle</button>}
              {' '}<button className="btn small secondary" onClick={() => setActive(null)}>Close panel</button>
            </div>
          </div>
          <table>
            <thead><tr><th>Asset</th><th>Result</th><th>Notes</th><th>Actions</th></tr></thead>
            <tbody>
              {active.items.map((item) => (
                <tr key={item.asset._id}>
                  <td>{item.asset.assetTag} - {item.asset.name}</td>
                  <td><StatusBadge status={item.result} /></td>
                  <td>{item.notes}</td>
                  <td>
                    {active.status !== 'Closed' && (
                      <>
                        <button className="btn small" onClick={() => markItem(item.asset._id, 'Verified')}>Verified</button>{' '}
                        <button className="btn small danger" onClick={() => markItem(item.asset._id, 'Missing')}>Missing</button>{' '}
                        <button className="btn small danger" onClick={() => markItem(item.asset._id, 'Damaged')}>Damaged</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
