import { useEffect, useState } from 'react';
import api from '../api/axios';
import StatusBadge from '../components/StatusBadge';

export default function Bookings() {
  const [bookings, setBookings] = useState([]);
  const [resources, setResources] = useState([]);
  const [conflict, setConflict] = useState(null);
  const [form, setForm] = useState({ assetId: '', startTime: '', endTime: '', purpose: '' });

  const load = async () => {
    const [b, r] = await Promise.all([api.get('/bookings'), api.get('/assets?status=Available')]);
    setBookings(b.data);
    setResources(r.data.filter((a) => a.isBookable));
  };
  useEffect(() => { load(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    setConflict(null);
    try {
      await api.post('/bookings', form);
      setForm({ assetId: '', startTime: '', endTime: '', purpose: '' });
      load();
    } catch (err) {
      if (err.response?.status === 409) setConflict(err.response.data.message);
      else alert(err.response?.data?.message || 'Failed to book');
    }
  };

  const cancel = async (id) => { await api.patch(`/bookings/${id}/cancel`); load(); };

  return (
    <div>
      <div className="section-title">Resource Booking</div>

      <div className="card">
        <strong>Book a Shared Resource</strong>
        <p className="muted">Overlapping time slots for the same resource are rejected automatically.</p>
        <form onSubmit={submit} className="form-grid" style={{ marginTop: 12 }}>
          <div className="form-row">
            <label>Resource</label>
            <select value={form.assetId} onChange={(e) => setForm({ ...form, assetId: e.target.value })} required>
              <option value="">-- select bookable resource --</option>
              {resources.map((r) => <option key={r._id} value={r._id}>{r.assetTag} - {r.name}</option>)}
            </select>
          </div>
          <div className="form-row">
            <label>Purpose</label>
            <input value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })} />
          </div>
          <div className="form-row">
            <label>Start Time</label>
            <input type="datetime-local" value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} required />
          </div>
          <div className="form-row">
            <label>End Time</label>
            <input type="datetime-local" value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} required />
          </div>
          <div style={{ alignSelf: 'end' }}><button className="btn">Book</button></div>
        </form>
        {conflict && <div className="error-text">{conflict}</div>}
      </div>

      <div className="card">
        <table>
          <thead><tr><th>Resource</th><th>Booked By</th><th>Start</th><th>End</th><th>Purpose</th><th>Status</th><th></th></tr></thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b._id}>
                <td>{b.asset?.assetTag} - {b.asset?.name}</td>
                <td>{b.bookedBy?.name}</td>
                <td>{new Date(b.startTime).toLocaleString()}</td>
                <td>{new Date(b.endTime).toLocaleString()}</td>
                <td>{b.purpose}</td>
                <td><StatusBadge status={b.status} /></td>
                <td>{['Upcoming', 'Ongoing'].includes(b.status) && <button className="btn small danger" onClick={() => cancel(b._id)}>Cancel</button>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
