const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const ctrl = require('../controllers/bookingController');

router.use(protect);
router.get('/', ctrl.listBookings);
router.post('/', ctrl.createBooking);
router.patch('/:id/cancel', ctrl.cancelBooking);
router.patch('/:id/reschedule', ctrl.rescheduleBooking);

module.exports = router;
