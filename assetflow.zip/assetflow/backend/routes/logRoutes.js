const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { listLogs } = require('../controllers/logController');

router.use(protect);
router.get('/', authorize('Admin'), listLogs);

module.exports = router;
