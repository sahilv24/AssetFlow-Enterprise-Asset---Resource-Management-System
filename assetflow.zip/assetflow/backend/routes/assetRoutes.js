const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/assetController');

router.use(protect);
router.get('/', ctrl.listAssets);
router.post('/', authorize('Admin', 'AssetManager'), ctrl.createAsset);
router.get('/:id', ctrl.getAsset);
router.get('/:id/history', ctrl.getAssetHistory);
router.put('/:id', authorize('Admin', 'AssetManager'), ctrl.updateAsset);

module.exports = router;
