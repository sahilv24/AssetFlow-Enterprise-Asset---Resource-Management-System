const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/maintenanceController');

router.use(protect);
router.get('/', ctrl.listRequests);
router.post('/', ctrl.createRequest);
router.patch('/:id/decision', authorize('Admin', 'AssetManager'), ctrl.decideRequest);
router.patch('/:id/assign-technician', authorize('Admin', 'AssetManager'), ctrl.assignTechnician);
router.patch('/:id/start-progress', authorize('Admin', 'AssetManager'), ctrl.startProgress);
router.patch('/:id/resolve', authorize('Admin', 'AssetManager'), ctrl.resolveRequest);

module.exports = router;
