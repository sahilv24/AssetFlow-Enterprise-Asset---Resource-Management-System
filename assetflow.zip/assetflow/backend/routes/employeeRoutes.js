const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/employeeController');

router.use(protect);
router.get('/', authorize('Admin'), ctrl.listEmployees);
router.put('/:id', authorize('Admin'), ctrl.updateEmployee);
router.patch('/:id/role', authorize('Admin'), ctrl.changeRole);

module.exports = router;
