const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/departmentController');

router.use(protect);
router.get('/', ctrl.listDepartments);
router.post('/', authorize('Admin'), ctrl.createDepartment);
router.put('/:id', authorize('Admin'), ctrl.updateDepartment);
router.patch('/:id/deactivate', authorize('Admin'), ctrl.deactivateDepartment);

module.exports = router;
