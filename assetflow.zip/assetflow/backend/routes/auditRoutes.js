const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/auditController');

router.use(protect);
router.get('/', ctrl.listAuditCycles);
router.post('/', authorize('Admin', 'AssetManager'), ctrl.createAuditCycle);
router.get('/:id', ctrl.getAuditCycle);
router.get('/:id/discrepancies', ctrl.getDiscrepancyReport);
router.patch('/:id/mark-item', ctrl.markAuditItem);
router.patch('/:id/close', authorize('Admin', 'AssetManager'), ctrl.closeAuditCycle);

module.exports = router;
