const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/allocationController');

router.use(protect);
router.get('/', ctrl.listAllocations);
router.get('/overdue', ctrl.listOverdueAllocations);
router.post('/', authorize('Admin', 'AssetManager', 'DepartmentHead'), ctrl.allocateAsset);
router.post('/transfer-request', ctrl.requestTransfer);
router.patch('/:id/transfer-decision', authorize('Admin', 'AssetManager', 'DepartmentHead'), ctrl.resolveTransfer);
router.patch('/:id/return', authorize('Admin', 'AssetManager', 'DepartmentHead'), ctrl.returnAsset);

module.exports = router;
