const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const ctrl = require('../controllers/categoryController');

router.use(protect);
router.get('/', ctrl.listCategories);
router.post('/', authorize('Admin'), ctrl.createCategory);
router.put('/:id', authorize('Admin'), ctrl.updateCategory);
router.patch('/:id/deactivate', authorize('Admin'), ctrl.deactivateCategory);

module.exports = router;
