const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { getKpis } = require('../controllers/dashboardController');

router.use(protect);
router.get('/kpis', getKpis);

module.exports = router;
