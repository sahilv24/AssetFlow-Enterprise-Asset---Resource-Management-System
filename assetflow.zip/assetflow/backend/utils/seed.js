// Seeds one Admin account so there's a way into the system (Admin is never self-assigned via signup).
// Run with: npm run seed
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('../config/db');
const User = require('../models/User');

const run = async () => {
  await connectDB();

  const existingAdmin = await User.findOne({ role: 'Admin' });
  if (existingAdmin) {
    console.log(`Admin already exists: ${existingAdmin.email}`);
    process.exit(0);
  }

  const admin = await User.create({
    name: 'System Admin',
    email: 'admin@assetflow.com',
    password: 'Admin@123',
    role: 'Admin',
    status: 'Active',
  });

  console.log('Admin account created:');
  console.log(`  email: ${admin.email}`);
  console.log('  password: Admin@123');
  console.log('Please log in and change this password.');
  process.exit(0);
};

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
