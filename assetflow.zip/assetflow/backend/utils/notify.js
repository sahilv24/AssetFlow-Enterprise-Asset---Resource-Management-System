const Notification = require('../models/Notification');

const notify = async (userId, type, message, link = '') => {
  try {
    if (!userId) return;
    await Notification.create({ user: userId, type, message, link });
  } catch (err) {
    console.error('Failed to create notification:', err.message);
  }
};

module.exports = notify;
