const Asset = require('../models/Asset');

// Generates sequential tags like AF-0001, AF-0002, ...
const generateAssetTag = async () => {
  const count = await Asset.countDocuments();
  const next = count + 1;
  return `AF-${String(next).padStart(4, '0')}`;
};

module.exports = generateAssetTag;
