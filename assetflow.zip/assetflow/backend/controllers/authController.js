const crypto = require('crypto');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');

// @desc  Signup - ALWAYS creates a plain Employee account. No role selection here.
// @route POST /api/auth/signup
const signup = asyncHandler(async (req, res) => {
  const { name, email, password, department } = req.body;
  if (!name || !email || !password) {
    return res.status(400).json({ message: 'Name, email and password are required' });
  }
  const existing = await User.findOne({ email: email.toLowerCase() });
  if (existing) return res.status(400).json({ message: 'An account with this email already exists' });

  const user = await User.create({
    name,
    email: email.toLowerCase(),
    password,
    department: department || null,
    role: 'Employee', // hardcoded regardless of what client sends
  });

  await logActivity(user._id, `${user.name} signed up`, 'Auth');

  res.status(201).json({
    token: generateToken(user._id),
    user: sanitize(user),
  });
});

// @desc  Login
// @route POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: (email || '').toLowerCase() }).select('+password');
  if (!user) return res.status(401).json({ message: 'Invalid email or password' });
  if (user.status !== 'Active') return res.status(403).json({ message: 'Account is inactive. Contact your Admin.' });

  const match = await user.comparePassword(password);
  if (!match) return res.status(401).json({ message: 'Invalid email or password' });

  await logActivity(user._id, `${user.name} logged in`, 'Auth');

  res.json({ token: generateToken(user._id), user: sanitize(user) });
});

// @desc  Get current logged-in user (session validation)
// @route GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  res.json({ user: sanitize(req.user) });
});

// @desc  Forgot password - generates a reset token (in production this would be emailed)
// @route POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: (req.body.email || '').toLowerCase() });
  if (!user) return res.status(200).json({ message: 'If that email exists, a reset link has been sent.' });

  const resetToken = crypto.randomBytes(32).toString('hex');
  user.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
  user.resetPasswordExpires = Date.now() + 60 * 60 * 1000; // 1 hour
  await user.save();

  // NOTE: wire this up to a real email provider in production.
  res.status(200).json({
    message: 'Reset token generated (demo mode - normally emailed).',
    demoResetToken: resetToken,
  });
});

// @desc  Reset password using token from forgot-password
// @route POST /api/auth/reset-password
const resetPassword = asyncHandler(async (req, res) => {
  const { token, newPassword } = req.body;
  const hashed = crypto.createHash('sha256').update(token || '').digest('hex');
  const user = await User.findOne({
    resetPasswordToken: hashed,
    resetPasswordExpires: { $gt: Date.now() },
  });
  if (!user) return res.status(400).json({ message: 'Token is invalid or has expired' });

  user.password = newPassword;
  user.resetPasswordToken = undefined;
  user.resetPasswordExpires = undefined;
  await user.save();

  res.json({ message: 'Password has been reset. Please log in.' });
});

function sanitize(user) {
  return {
    _id: user._id,
    name: user.name,
    email: user.email,
    role: user.role,
    department: user.department,
    status: user.status,
  };
}

module.exports = { signup, login, getMe, forgotPassword, resetPassword };
