const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');
const notify = require('../utils/notify');

// Employee Directory: list all employees (all roles) - Admin only screen
const listEmployees = asyncHandler(async (req, res) => {
  const employees = await User.find().populate('department', 'name').sort('-createdAt');
  res.json(employees);
});

const updateEmployee = asyncHandler(async (req, res) => {
  const { name, email, department, status } = req.body;
  const employee = await User.findByIdAndUpdate(
    req.params.id,
    { name, email, department, status },
    { new: true, runValidators: true }
  );
  if (!employee) return res.status(404).json({ message: 'Employee not found' });
  res.json(employee);
});

// The ONLY place roles get assigned: Admin promotes an Employee to DepartmentHead or AssetManager
const changeRole = asyncHandler(async (req, res) => {
  const { role } = req.body;
  const allowed = ['Employee', 'DepartmentHead', 'AssetManager'];
  if (!allowed.includes(role)) {
    return res.status(400).json({ message: `Role must be one of: ${allowed.join(', ')}` });
  }
  const employee = await User.findById(req.params.id);
  if (!employee) return res.status(404).json({ message: 'Employee not found' });
  if (employee.role === 'Admin') return res.status(400).json({ message: 'Cannot change role of an Admin account' });

  employee.role = role;
  await employee.save();

  await logActivity(req.user._id, `Promoted ${employee.name} to ${role}`, 'Employee');
  await notify(employee._id, 'General', `You have been assigned the role of ${role}.`);

  res.json(employee);
});

module.exports = { listEmployees, updateEmployee, changeRole };
