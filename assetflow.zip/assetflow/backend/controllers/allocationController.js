const Allocation = require('../models/Allocation');
const Asset = require('../models/Asset');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');
const notify = require('../utils/notify');

// @desc  Allocate an asset to an employee/department.
//        Conflict rule: blocks if the asset is already actively allocated.
const allocateAsset = asyncHandler(async (req, res) => {
  const { assetId, allocatedTo, department, expectedReturnDate } = req.body;

  const asset = await Asset.findById(assetId);
  if (!asset) return res.status(404).json({ message: 'Asset not found' });

  const existingActive = await Allocation.findOne({ asset: assetId, status: 'Active' }).populate('allocatedTo', 'name');
  if (existingActive) {
    return res.status(409).json({
      message: `This asset is currently held by ${existingActive.allocatedTo ? existingActive.allocatedTo.name : 'another department'}. Use a Transfer Request instead.`,
      currentAllocation: existingActive,
      transferAvailable: true,
    });
  }

  if (!['Available'].includes(asset.status)) {
    return res.status(409).json({ message: `Asset is currently "${asset.status}" and cannot be allocated.` });
  }

  const allocation = await Allocation.create({
    asset: assetId,
    allocatedTo: allocatedTo || null,
    department: department || null,
    expectedReturnDate: expectedReturnDate || null,
    createdBy: req.user._id,
  });

  asset.status = 'Allocated';
  await asset.save();

  await logActivity(req.user._id, `Allocated asset ${asset.assetTag} to user/department`, 'Allocation');
  if (allocatedTo) await notify(allocatedTo, 'AssetAssigned', `Asset ${asset.assetTag} - ${asset.name} has been allocated to you.`);

  res.status(201).json(allocation);
});

const listAllocations = asyncHandler(async (req, res) => {
  const { status, department, employee } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (department) filter.department = department;
  if (employee) filter.allocatedTo = employee;

  const allocations = await Allocation.find(filter)
    .populate('asset', 'name assetTag status')
    .populate('allocatedTo', 'name email')
    .populate('department', 'name')
    .sort('-createdAt');
  res.json(allocations);
});

// @desc  Overdue allocations (past Expected Return Date, still Active)
const listOverdueAllocations = asyncHandler(async (req, res) => {
  const overdue = await Allocation.find({
    status: 'Active',
    expectedReturnDate: { $ne: null, $lt: new Date() },
  })
    .populate('asset', 'name assetTag')
    .populate('allocatedTo', 'name email')
    .populate('department', 'name');
  res.json(overdue);
});

// @desc  Requester initiates a transfer request on an actively-allocated asset
const requestTransfer = asyncHandler(async (req, res) => {
  const { allocationId, requestedTo } = req.body;
  const allocation = await Allocation.findById(allocationId);
  if (!allocation || allocation.status !== 'Active') {
    return res.status(404).json({ message: 'Active allocation not found' });
  }
  if (allocation.transferRequest.status === 'Requested') {
    return res.status(409).json({ message: 'A transfer request is already pending for this allocation' });
  }

  allocation.transferRequest = {
    requestedBy: req.user._id,
    requestedTo,
    status: 'Requested',
    requestedAt: new Date(),
    approvedBy: null,
    resolvedAt: null,
  };
  await allocation.save();

  await logActivity(req.user._id, `Requested transfer for allocation ${allocation._id}`, 'Allocation');
  res.status(201).json(allocation);
});

// @desc  Asset Manager / Department Head approves or rejects a transfer request
const resolveTransfer = asyncHandler(async (req, res) => {
  const { decision } = req.body; // 'Approved' | 'Rejected'
  const allocation = await Allocation.findById(req.params.id).populate('asset');
  if (!allocation) return res.status(404).json({ message: 'Allocation not found' });
  if (allocation.transferRequest.status !== 'Requested') {
    return res.status(400).json({ message: 'No pending transfer request on this allocation' });
  }

  if (decision === 'Rejected') {
    allocation.transferRequest.status = 'Rejected';
    allocation.transferRequest.approvedBy = req.user._id;
    allocation.transferRequest.resolvedAt = new Date();
    await allocation.save();
    return res.json(allocation);
  }

  // Approved -> Re-allocated: close old allocation, open a new one, history updated automatically
  allocation.status = 'Transferred';
  allocation.actualReturnDate = new Date();
  allocation.transferRequest.status = 'Approved';
  allocation.transferRequest.approvedBy = req.user._id;
  allocation.transferRequest.resolvedAt = new Date();
  await allocation.save();

  const newAllocation = await Allocation.create({
    asset: allocation.asset._id,
    allocatedTo: allocation.transferRequest.requestedTo,
    department: allocation.department,
    expectedReturnDate: null,
    createdBy: req.user._id,
  });

  await logActivity(req.user._id, `Approved transfer, re-allocated ${allocation.asset.assetTag}`, 'Allocation');
  await notify(allocation.transferRequest.requestedTo, 'TransferApproved', `Asset ${allocation.asset.assetTag} has been transferred to you.`);

  res.json({ closedAllocation: allocation, newAllocation });
});

// @desc  Mark an asset returned - reverts status to Available
const returnAsset = asyncHandler(async (req, res) => {
  const { conditionNotes } = req.body;
  const allocation = await Allocation.findById(req.params.id).populate('asset');
  if (!allocation || allocation.status !== 'Active') {
    return res.status(404).json({ message: 'Active allocation not found' });
  }

  allocation.status = 'Returned';
  allocation.actualReturnDate = new Date();
  allocation.returnConditionNotes = conditionNotes || '';
  await allocation.save();

  const asset = await Asset.findById(allocation.asset._id);
  asset.status = 'Available';
  await asset.save();

  await logActivity(req.user._id, `Returned asset ${asset.assetTag}`, 'Allocation');
  res.json(allocation);
});

module.exports = {
  allocateAsset, listAllocations, listOverdueAllocations,
  requestTransfer, resolveTransfer, returnAsset,
};
