const MaintenanceRequest = require('../models/MaintenanceRequest');
const Asset = require('../models/Asset');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');
const notify = require('../utils/notify');

// @desc  Raise a maintenance request (Pending). Asset status is untouched until approval.
const createRequest = asyncHandler(async (req, res) => {
  const { assetId, issueDescription, priority, photoUrl } = req.body;
  const asset = await Asset.findById(assetId);
  if (!asset) return res.status(404).json({ message: 'Asset not found' });

  const request = await MaintenanceRequest.create({
    asset: assetId, raisedBy: req.user._id, issueDescription, priority: priority || 'Medium', photoUrl,
  });

  await logActivity(req.user._id, `Raised maintenance request for ${asset.assetTag}`, 'Maintenance');
  res.status(201).json(request);
});

const listRequests = asyncHandler(async (req, res) => {
  const { status, assetId } = req.query;
  const filter = {};
  if (status) filter.status = status;
  if (assetId) filter.asset = assetId;

  const requests = await MaintenanceRequest.find(filter)
    .populate('asset', 'name assetTag status')
    .populate('raisedBy', 'name email')
    .sort('-createdAt');
  res.json(requests);
});

// @desc  Asset Manager approves/rejects. On approval, asset flips to Under Maintenance.
const decideRequest = asyncHandler(async (req, res) => {
  const { decision, rejectionReason } = req.body; // 'Approved' | 'Rejected'
  const request = await MaintenanceRequest.findById(req.params.id).populate('asset');
  if (!request) return res.status(404).json({ message: 'Maintenance request not found' });
  if (request.status !== 'Pending') return res.status(400).json({ message: 'Request already decided' });

  request.status = decision;
  request.approvedBy = req.user._id;
  if (decision === 'Rejected') request.rejectionReason = rejectionReason || '';
  await request.save();

  if (decision === 'Approved') {
    const asset = await Asset.findById(request.asset._id);
    asset.status = 'Under Maintenance';
    await asset.save();
    await notify(request.raisedBy, 'MaintenanceApproved', `Maintenance approved for ${asset.assetTag}. Work will begin shortly.`);
  } else {
    await notify(request.raisedBy, 'MaintenanceRejected', `Maintenance request for asset was rejected: ${rejectionReason || 'no reason given'}.`);
  }

  await logActivity(req.user._id, `${decision} maintenance request ${request._id}`, 'Maintenance');
  res.json(request);
});

const assignTechnician = asyncHandler(async (req, res) => {
  const { technician } = req.body;
  const request = await MaintenanceRequest.findById(req.params.id);
  if (!request) return res.status(404).json({ message: 'Request not found' });
  if (request.status !== 'Approved') return res.status(400).json({ message: 'Request must be Approved first' });

  request.technician = technician;
  request.status = 'Technician Assigned';
  await request.save();
  res.json(request);
});

const startProgress = asyncHandler(async (req, res) => {
  const request = await MaintenanceRequest.findById(req.params.id);
  if (!request) return res.status(404).json({ message: 'Request not found' });
  if (request.status !== 'Technician Assigned') return res.status(400).json({ message: 'Technician must be assigned first' });
  request.status = 'In Progress';
  await request.save();
  res.json(request);
});

// @desc  Resolve - asset status auto-reverts to Available
const resolveRequest = asyncHandler(async (req, res) => {
  const { resolutionNotes } = req.body;
  const request = await MaintenanceRequest.findById(req.params.id).populate('asset');
  if (!request) return res.status(404).json({ message: 'Request not found' });
  if (!['In Progress', 'Technician Assigned', 'Approved'].includes(request.status)) {
    return res.status(400).json({ message: 'Request is not in a resolvable state' });
  }

  request.status = 'Resolved';
  request.resolutionNotes = resolutionNotes || '';
  request.resolvedAt = new Date();
  await request.save();

  const asset = await Asset.findById(request.asset._id);
  asset.status = 'Available';
  await asset.save();

  await logActivity(req.user._id, `Resolved maintenance request ${request._id}`, 'Maintenance');
  res.json(request);
});

module.exports = { createRequest, listRequests, decideRequest, assignTechnician, startProgress, resolveRequest };
