const AssetCategory = require('../models/AssetCategory');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');

const listCategories = asyncHandler(async (req, res) => {
  const categories = await AssetCategory.find().sort('-createdAt');
  res.json(categories);
});

const createCategory = asyncHandler(async (req, res) => {
  const { name, description, customFields, status } = req.body;
  const category = await AssetCategory.create({ name, description, customFields: customFields || [], status });
  await logActivity(req.user._id, `Created asset category "${category.name}"`, 'AssetCategory');
  res.status(201).json(category);
});

const updateCategory = asyncHandler(async (req, res) => {
  const category = await AssetCategory.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!category) return res.status(404).json({ message: 'Category not found' });
  await logActivity(req.user._id, `Updated asset category "${category.name}"`, 'AssetCategory');
  res.json(category);
});

const deactivateCategory = asyncHandler(async (req, res) => {
  const category = await AssetCategory.findByIdAndUpdate(req.params.id, { status: 'Inactive' }, { new: true });
  if (!category) return res.status(404).json({ message: 'Category not found' });
  res.json(category);
});

module.exports = { listCategories, createCategory, updateCategory, deactivateCategory };
