const Asset = require('../models/Asset');
const Allocation = require('../models/Allocation');
const MaintenanceRequest = require('../models/MaintenanceRequest');
const generateAssetTag = require('../utils/generateAssetTag');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');

// @desc  Register a new asset - always enters as Available
const createAsset = asyncHandler(async (req, res) => {
  const {
    name, category, serialNumber, acquisitionDate, acquisitionCost,
    condition, location, department, photoUrl, documents, isBookable,
    qrCode, customFieldValues,
  } = req.body;

  if (!name || !category) return res.status(400).json({ message: 'Name and category are required' });

  const assetTag = await generateAssetTag();

  const asset = await Asset.create({
    name, category, serialNumber, acquisitionDate, acquisitionCost,
    condition, location, department: department || null, photoUrl,
    documents: documents || [], isBookable: !!isBookable, qrCode,
    customFieldValues: customFieldValues || {},
    assetTag,
    status: 'Available',
  });

  await logActivity(req.user._id, `Registered asset ${asset.assetTag} - ${asset.name}`, 'Asset');
  res.status(201).json(asset);
});

// @desc  Search / filter / list assets
const listAssets = asyncHandler(async (req, res) => {
  const { q, category, status, department, location } = req.query;
  const filter = {};
  if (category) filter.category = category;
  if (status) filter.status = status;
  if (department) filter.department = department;
  if (location) filter.location = new RegExp(location, 'i');
  if (q) {
    filter.$or = [
      { name: new RegExp(q, 'i') },
      { assetTag: new RegExp(q, 'i') },
      { serialNumber: new RegExp(q, 'i') },
      { qrCode: new RegExp(q, 'i') },
    ];
  }
  const assets = await Asset.find(filter)
    .populate('category', 'name')
    .populate('department', 'name')
    .sort('-createdAt');
  res.json(assets);
});

const getAsset = asyncHandler(async (req, res) => {
  const asset = await Asset.findById(req.params.id).populate('category').populate('department', 'name');
  if (!asset) return res.status(404).json({ message: 'Asset not found' });
  res.json(asset);
});

const updateAsset = asyncHandler(async (req, res) => {
  const asset = await Asset.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!asset) return res.status(404).json({ message: 'Asset not found' });
  await logActivity(req.user._id, `Updated asset ${asset.assetTag}`, 'Asset');
  res.json(asset);
});

// @desc  Full per-asset history: allocation history + maintenance history
const getAssetHistory = asyncHandler(async (req, res) => {
  const asset = await Asset.findById(req.params.id);
  if (!asset) return res.status(404).json({ message: 'Asset not found' });

  const allocationHistory = await Allocation.find({ asset: asset._id })
    .populate('allocatedTo', 'name email')
    .populate('department', 'name')
    .sort('-createdAt');

  const maintenanceHistory = await MaintenanceRequest.find({ asset: asset._id })
    .populate('raisedBy', 'name')
    .sort('-createdAt');

  res.json({ allocationHistory, maintenanceHistory });
});

module.exports = { createAsset, listAssets, getAsset, updateAsset, getAssetHistory };
