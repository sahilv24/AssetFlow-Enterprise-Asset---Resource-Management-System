const ActivityLog = require('../models/ActivityLog');
const asyncHandler = require('../utils/asyncHandler');

const listLogs = asyncHandler(async (req, res) => {
  const { module, user } = req.query;
  const filter = {};
  if (module) filter.module = module;
  if (user) filter.user = user;
  const logs = await ActivityLog.find(filter).populate('user', 'name email role').sort('-createdAt').limit(300);
  res.json(logs);
});

module.exports = { listLogs };
