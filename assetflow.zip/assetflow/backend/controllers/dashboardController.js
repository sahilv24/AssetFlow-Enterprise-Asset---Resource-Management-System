const Asset = require('../models/Asset');
const Allocation = require('../models/Allocation');
const Booking = require('../models/Booking');
const MaintenanceRequest = require('../models/MaintenanceRequest');
const asyncHandler = require('../utils/asyncHandler');

// @desc  KPI cards + overdue vs upcoming breakdown for the Dashboard screen
const getKpis = asyncHandler(async (req, res) => {
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);

  const [
    assetsAvailable, assetsAllocated, maintenanceToday, activeBookings,
    pendingTransfers, upcomingReturns, overdueReturns, overdueBookingsCount,
  ] = await Promise.all([
    Asset.countDocuments({ status: 'Available' }),
    Asset.countDocuments({ status: 'Allocated' }),
    MaintenanceRequest.countDocuments({ updatedAt: { $gte: startOfDay, $lt: endOfDay } }),
    Booking.countDocuments({ status: { $in: ['Upcoming', 'Ongoing'] } }),
    Allocation.countDocuments({ 'transferRequest.status': 'Requested' }),
    Allocation.countDocuments({ status: 'Active', expectedReturnDate: { $ne: null, $gte: now } }),
    Allocation.countDocuments({ status: 'Active', expectedReturnDate: { $ne: null, $lt: now } }),
    Booking.countDocuments({ status: 'Upcoming', endTime: { $lt: now } }),
  ]);

  res.json({
    assetsAvailable, assetsAllocated, maintenanceToday, activeBookings,
    pendingTransfers, upcomingReturns, overdueReturns, overdueBookingsCount,
  });
});

module.exports = { getKpis };
