const Department = require('../models/Department');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');

const listDepartments = asyncHandler(async (req, res) => {
  const departments = await Department.find()
    .populate('departmentHead', 'name email')
    .populate('parentDepartment', 'name')
    .sort('-createdAt');
  res.json(departments);
});

const createDepartment = asyncHandler(async (req, res) => {
  const { name, departmentHead, parentDepartment, status } = req.body;
  const dept = await Department.create({ name, departmentHead: departmentHead || null, parentDepartment: parentDepartment || null, status });
  await logActivity(req.user._id, `Created department "${dept.name}"`, 'Department');
  res.status(201).json(dept);
});

const updateDepartment = asyncHandler(async (req, res) => {
  const dept = await Department.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
  if (!dept) return res.status(404).json({ message: 'Department not found' });
  await logActivity(req.user._id, `Updated department "${dept.name}"`, 'Department');
  res.json(dept);
});

const deactivateDepartment = asyncHandler(async (req, res) => {
  const dept = await Department.findByIdAndUpdate(req.params.id, { status: 'Inactive' }, { new: true });
  if (!dept) return res.status(404).json({ message: 'Department not found' });
  await logActivity(req.user._id, `Deactivated department "${dept.name}"`, 'Department');
  res.json(dept);
});

module.exports = { listDepartments, createDepartment, updateDepartment, deactivateDepartment };
