const AuditCycle = require('../models/AuditCycle');
const Asset = require('../models/Asset');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');
const notify = require('../utils/notify');

// @desc  Create an audit cycle for a scope (department/location + date range), with assigned assets
const createAuditCycle = asyncHandler(async (req, res) => {
  const { name, scopeDepartment, scopeLocation, startDate, endDate, auditors } = req.body;

  const assetFilter = {};
  if (scopeDepartment) assetFilter.department = scopeDepartment;
  if (scopeLocation) assetFilter.location = new RegExp(scopeLocation, 'i');
  const assetsInScope = await Asset.find(assetFilter).select('_id');

  const cycle = await AuditCycle.create({
    name, scopeDepartment: scopeDepartment || null, scopeLocation: scopeLocation || '',
    startDate, endDate, auditors: auditors || [], createdBy: req.user._id,
    items: assetsInScope.map((a) => ({ asset: a._id, result: 'Pending' })),
    status: 'Planned',
  });

  await logActivity(req.user._id, `Created audit cycle "${cycle.name}" with ${assetsInScope.length} assets in scope`, 'Audit');
  for (const auditorId of auditors || []) {
    await notify(auditorId, 'General', `You have been assigned as an auditor for cycle "${cycle.name}".`);
  }

  res.status(201).json(cycle);
});

const listAuditCycles = asyncHandler(async (req, res) => {
  const cycles = await AuditCycle.find()
    .populate('scopeDepartment', 'name')
    .populate('auditors', 'name email')
    .populate('items.asset', 'name assetTag')
    .sort('-createdAt');
  res.json(cycles);
});

const getAuditCycle = asyncHandler(async (req, res) => {
  const cycle = await AuditCycle.findById(req.params.id)
    .populate('scopeDepartment', 'name')
    .populate('auditors', 'name email')
    .populate('items.asset', 'name assetTag status')
    .populate('items.checkedBy', 'name');
  if (!cycle) return res.status(404).json({ message: 'Audit cycle not found' });
  res.json(cycle);
});

// @desc  Auditor marks each asset item: Verified / Missing / Damaged
const markAuditItem = asyncHandler(async (req, res) => {
  const { assetId, result, notes } = req.body;
  const cycle = await AuditCycle.findById(req.params.id);
  if (!cycle) return res.status(404).json({ message: 'Audit cycle not found' });
  if (cycle.status === 'Closed') return res.status(400).json({ message: 'Audit cycle is closed' });

  const item = cycle.items.find((i) => i.asset.toString() === assetId);
  if (!item) return res.status(404).json({ message: 'Asset is not part of this audit cycle scope' });

  item.result = result;
  item.notes = notes || '';
  item.checkedBy = req.user._id;
  item.checkedAt = new Date();
  if (cycle.status === 'Planned') cycle.status = 'In Progress';
  await cycle.save();

  res.json(cycle);
});

// @desc  Auto-generated discrepancy report for flagged (Missing/Damaged) items
const getDiscrepancyReport = asyncHandler(async (req, res) => {
  const cycle = await AuditCycle.findById(req.params.id).populate('items.asset', 'name assetTag location');
  if (!cycle) return res.status(404).json({ message: 'Audit cycle not found' });
  const discrepancies = cycle.items.filter((i) => ['Missing', 'Damaged'].includes(i.result));
  res.json({ cycleName: cycle.name, discrepancies });
});

// @desc  Close the audit cycle: locks it, updates asset statuses (e.g. Lost for confirmed-missing)
const closeAuditCycle = asyncHandler(async (req, res) => {
  const cycle = await AuditCycle.findById(req.params.id);
  if (!cycle) return res.status(404).json({ message: 'Audit cycle not found' });
  if (cycle.status === 'Closed') return res.status(400).json({ message: 'Already closed' });

  for (const item of cycle.items) {
    if (item.result === 'Missing') {
      await Asset.findByIdAndUpdate(item.asset, { status: 'Lost' });
    } else if (item.result === 'Damaged') {
      await Asset.findByIdAndUpdate(item.asset, { condition: 'Damaged' });
    }
  }

  cycle.status = 'Closed';
  cycle.closedAt = new Date();
  await cycle.save();

  const flagged = cycle.items.filter((i) => ['Missing', 'Damaged'].includes(i.result));
  for (const auditorId of cycle.auditors) {
    if (flagged.length > 0) {
      await notify(auditorId, 'AuditDiscrepancy', `Audit cycle "${cycle.name}" closed with ${flagged.length} discrepancy item(s).`);
    }
  }

  await logActivity(req.user._id, `Closed audit cycle "${cycle.name}"`, 'Audit');
  res.json(cycle);
});

module.exports = { createAuditCycle, listAuditCycles, getAuditCycle, markAuditItem, getDiscrepancyReport, closeAuditCycle };
