const Booking = require('../models/Booking');
const Asset = require('../models/Asset');
const asyncHandler = require('../utils/asyncHandler');
const logActivity = require('../utils/logActivity');
const notify = require('../utils/notify');

// Two bookings overlap if start1 < end2 AND end1 > start2.
// A booking starting exactly when another ends is allowed (no overlap).
const hasOverlap = async (assetId, startTime, endTime, excludeBookingId = null) => {
  const filter = {
    asset: assetId,
    status: { $in: ['Upcoming', 'Ongoing'] },
    startTime: { $lt: endTime },
    endTime: { $gt: startTime },
  };
  if (excludeBookingId) filter._id = { $ne: excludeBookingId };
  const conflict = await Booking.findOne(filter);
  return conflict;
};

const createBooking = asyncHandler(async (req, res) => {
  const { assetId, startTime, endTime, purpose, department } = req.body;

  const asset = await Asset.findById(assetId);
  if (!asset) return res.status(404).json({ message: 'Resource not found' });
  if (!asset.isBookable) return res.status(400).json({ message: 'This asset is not marked as a bookable resource' });

  const start = new Date(startTime);
  const end = new Date(endTime);
  if (!(start < end)) return res.status(400).json({ message: 'End time must be after start time' });

  const conflict = await hasOverlap(assetId, start, end);
  if (conflict) {
    return res.status(409).json({
      message: `This resource is already booked from ${conflict.startTime.toISOString()} to ${conflict.endTime.toISOString()}, which overlaps your requested slot.`,
      conflictingBooking: conflict,
    });
  }

  const booking = await Booking.create({
    asset: assetId, bookedBy: req.user._id, department: department || req.user.department,
    purpose, startTime: start, endTime: end, status: 'Upcoming',
  });

  await logActivity(req.user._id, `Booked resource ${asset.assetTag} (${asset.name})`, 'Booking');
  await notify(req.user._id, 'BookingConfirmed', `Your booking for ${asset.name} is confirmed.`);

  res.status(201).json(booking);
});

const listBookings = asyncHandler(async (req, res) => {
  const { assetId, status } = req.query;
  const filter = {};
  if (assetId) filter.asset = assetId;
  if (status) filter.status = status;

  const bookings = await Booking.find(filter)
    .populate('asset', 'name assetTag')
    .populate('bookedBy', 'name email')
    .sort('startTime');
  res.json(bookings);
});

const cancelBooking = asyncHandler(async (req, res) => {
  const booking = await Booking.findById(req.params.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found' });
  booking.status = 'Cancelled';
  await booking.save();
  await logActivity(req.user._id, `Cancelled booking ${booking._id}`, 'Booking');
  await notify(booking.bookedBy, 'BookingCancelled', 'Your booking has been cancelled.');
  res.json(booking);
});

const rescheduleBooking = asyncHandler(async (req, res) => {
  const { startTime, endTime } = req.body;
  const booking = await Booking.findById(req.params.id);
  if (!booking) return res.status(404).json({ message: 'Booking not found' });

  const start = new Date(startTime);
  const end = new Date(endTime);
  if (!(start < end)) return res.status(400).json({ message: 'End time must be after start time' });

  const conflict = await hasOverlap(booking.asset, start, end, booking._id);
  if (conflict) {
    return res.status(409).json({ message: 'The new time slot overlaps an existing booking', conflictingBooking: conflict });
  }

  booking.startTime = start;
  booking.endTime = end;
  booking.status = 'Upcoming';
  await booking.save();
  res.json(booking);
});

module.exports = { createBooking, listBookings, cancelBooking, rescheduleBooking };
