# AssetFlow — Enterprise Asset & Resource Management System

Full MERN-stack implementation of the AssetFlow problem statement: department/category/employee
setup, asset lifecycle tracking, allocation with conflict handling, resource booking with overlap
validation, maintenance approval workflow, audit cycles with discrepancy reports, notifications,
activity logs, and a KPI dashboard.

## Stack
- **Backend**: Node.js, Express, MongoDB (Mongoose), JWT auth, bcrypt
- **Frontend**: React (Vite), React Router, Axios

## Project structure
```
assetflow/
  backend/
  frontend/
```

## Prerequisites
- Node.js 18+
- MongoDB running locally (or a MongoDB Atlas connection string)

## 1. Backend setup
```bash
cd assetflow/backend
npm install
cp .env.example .env
# edit .env if needed (MONGO_URI, JWT_SECRET, etc.)
npm run seed     # creates the initial Admin account (admin@assetflow.com / Admin@123)
npm run dev      # starts API on http://localhost:5000
```

## 2. Frontend setup
Open a second terminal:
```bash
cd assetflow/frontend
npm install
cp .env.example .env
npm run dev      # starts app on http://localhost:5173
```

## 3. Using the app
1. Go to http://localhost:5173/login and log in as `admin@assetflow.com` / `Admin@123`.
2. Change the admin password in production use (this is a demo seed).
3. In **Organization Setup**, create departments and asset categories, and promote
   employees to Department Head / Asset Manager (this is the only place roles are assigned —
   new signups always land as plain Employees).
4. Register assets, allocate them, book shared resources, raise maintenance requests, and
   run audit cycles from their respective screens.

## Notes
- Roles: `Admin`, `AssetManager`, `DepartmentHead`, `Employee`. Admin is seeded via script, never
  self-assigned through signup.
- The allocation conflict rule, booking overlap validation, maintenance approval flow, and audit
  discrepancy/close logic are all implemented server-side in the corresponding controllers under
  `backend/controllers/`.
- "Forgot password" issues a demo reset token in the API response instead of sending an email —
  wire up a real mail provider (e.g. Nodemailer + SMTP/SendGrid) for production use.
- This is a hackathon-grade scaffold: functional, not pixel-polished. Style freely in
  `frontend/src/styles/index.css`.
